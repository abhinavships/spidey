# DELEGATION PACKET — M1 `app/browser/driver.py` — owner: Codex — Wave B

> **How to send:** paste the full text of `docs/contracts.md` (v2) first, then everything below this line, in one message.
> This is the highest-risk module in the build. Read §3 twice.

---

## 1. Your task

Implement **ONLY** `app/browser/driver.py`, plus `tests/test_driver.py` and any static fixtures under `tests/pages/`. Import only from `app.schemas`, `playwright.async_api`, and stdlib. Do not create, modify, or stub any other file — including `tests/fakes.py` and `app/schemas.py`. Do not change any signature in `contracts.md` — if a signature seems wrong, say so and stop.

Playwright is pinned at **1.62.0**. Do not use any API that was removed or added outside that version.

## 2. Signatures

```python
from app.schemas import ActResult, BlockedAction, LocatorBundle, PageSnapshot, Step

class Driver:
    async def start(self, entry_url: str, storage_state: str | None = None,
                    cdp_endpoint: str | None = None) -> None: ...
    async def stop(self) -> None: ...
    async def snapshot(self) -> PageSnapshot: ...
    async def screenshot(self, path: str) -> str: ...
    async def act(self, step: Step, resolver, guard) -> ActResult: ...
    async def find(self, bundle: LocatorBundle, timeout_ms: int) -> Any | None: ...
```

## 3. The two things that will break the demo if you get them wrong

**(a) CDP attach. This recipe is VERIFIED WORKING against real Chrome. Do not redesign it.**

```python
browser = await playwright.chromium.connect_over_cdp(cdp_endpoint)  # "http://localhost:9222"
context = browser.contexts[0]
page = context.pages[0]
```

- When `cdp_endpoint` is not None: attach exactly as above and **reuse the existing tab**. Do not call `launch()`. Do not call `new_context()`. Do not pass `storage_state` — the real Chrome profile at `~/wa-profile` already holds the logged-in GitHub and Gmail sessions, and creating a fresh context throws them away.
- When `cdp_endpoint` is None: fall back to `chromium.launch()` + `new_context(storage_state=...)`. This path is for tests and CI only.
- `stop()` when attached over CDP must **detach only** — `await browser.close()` on a CDP connection kills the judge's Chrome and the demo is unrecoverable. Close the playwright connection, leave the browser and page alive. On the `launch()` path, close normally.
- Re-read `browser.contexts[0].pages[0]` at the top of each `act()` rather than caching `self.page` forever. If someone switches tabs mid-demo we follow them instead of throwing.
- If `connect_over_cdp` fails, raise a `RuntimeError` whose message names port 9222 and `./launch_browser.sh`. M11 turns that into a readable error event.

**(b) `page.accessibility` is REMOVED in Playwright 1.62.** It does not exist. Calling it AttributeErrors at demo time. Use:

```python
digest = await page.locator("body").aria_snapshot()   # -> str
```

Truncate `a11y_digest` to 4000 chars and `visible_text` to 3000 (`page.locator("body").inner_text()`).

## 4. `act()` — the only place actions happen

Order of operations, normative:

1. `verdict = guard.check(step, await self.snapshot())`. If `not verdict.allowed`, raise `BlockedAction(verdict, step.id)` **before any Playwright call touches the page**. A test asserts this via a spy: zero page interactions on the blocked path.
2. Capture a "before" signal for the effect summary (url + title + a short hash or prefix of `inner_text`).
3. `handle = await self.find(step.locator, step.timeout_ms)` — for NAVIGATE and SCROLL there is no locator; act directly.
4. On miss: call `resolver.heal(step.locator, await self.snapshot())` **exactly once**. If it returns a bundle, write it back onto `step.locator` (update `heal_count`, `healed_at`), retry `find` once, and set `healed=True` on success. If heal returns `None` or the retry misses, return `ActResult(ok=False, error=...)`.
5. Perform the action per `step.action`: NAVIGATE → `page.goto(step.value)`; CLICK → `handle.click()`; TYPE → `handle.fill(step.value)`; SELECT → `handle.select_option(step.value)`; SCROLL → `page.mouse.wheel`; WAIT_FOR → `handle.wait_for(state="visible")`; ASSERT → verify and set `ok` accordingly without interacting.
6. Compare before/after and write **one sentence** into `effect` — e.g. `"the new issue form opened"`. It is fed to the narrator and to QA, so it must be human-readable, not a diff dump.
7. Wrap steps 3–6 so that **no exception escapes except `BlockedAction`**. Every Playwright error becomes `ActResult(ok=False, error=str(exc))`. Every path has a timeout; nothing may hang.

`find()` tries `bundle.candidates` **in order** and returns the first that resolves within `timeout_ms`. Map strategies: `test_id` → `get_by_test_id`, `role` → `get_by_role(value, name=name, exact=exact)`, `label` → `get_by_label`, `placeholder` → `get_by_placeholder`, `text` → `get_by_text`, `css` → `locator`. Returns `None` on total miss — never raises on a miss.

## 5. Your tests (from plan_unittests.md §M1 — the spec)

Against a local static HTML fixture in `tests/pages/`. **No GitHub, no Gmail, no network, no live Chrome in CI.** Mock the playwright object for the attach tests.

- `snapshot()` returns non-empty `a11y_digest` and `visible_text`, correct url/title
- `a11y_digest` comes from `aria_snapshot()`; assert the module source never contains the string `page.accessibility`
- A huge page truncates to 4000 / 3000
- `start(cdp_endpoint="http://localhost:9222")` calls `connect_over_cdp` and reuses `browser.contexts[0].pages[0]` — assert on the mock; assert `launch` and `new_context` were **not** called
- `start(cdp_endpoint=None)` takes the `launch()` + `storage_state` path
- `stop()` after a CDP attach does **not** call `browser.close()` or `page.close()`
- Attach failure → `RuntimeError` mentioning 9222
- `find()` returns a handle for a valid bundle; `None` after `timeout_ms` for a bogus one, taking ≥ timeout but < timeout + 2s
- Candidate order is respected: with two matching candidates, the first is used
- `act()` on a CLICK with a good locator → `ok=True`, page state changed, `effect` non-empty
- `act()` on a miss calls `resolver.heal()` **exactly once**, retries, reports `healed=True`
- `act()` on a miss where heal also fails → `ok=False`, `error` set, no exception escapes
- `act()` raises `BlockedAction` when the guard refuses, **and the page is not touched** (spy asserts zero Playwright interaction)

## 6. Acceptance

Paste back `app/browser/driver.py`, `tests/test_driver.py`, and any fixture HTML, as complete files. We run `pytest tests/test_driver.py`. Green or regenerate. Separately, we run the live CDP smoke by hand — that one is on us, not you.
