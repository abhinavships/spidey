# DEMO 1 RUNBOOK — integrate, verify, record

## State at handoff

| Artifact | Status |
|---|---|
| `docs/contracts.md` | v2, frozen |
| `docs/plan.md` | v2 |
| `docs/plan_unittests.md` | v2 |
| `app/schemas.py` | written in-house, frozen, 19 tests green |
| `app/runtime/orchestrator.py` | v0 written, linear loop, `_drain_events()` is a no-op stub |
| `tests/fakes.py` | written in-house — **delegates may not edit** |
| `tests/test_schemas.py`, `tests/test_integration.py` | green (19 passed) |
| `workflows/gh-issue.v1.json` | hardcoded 10-step spec, valid against M0 |
| `docs/delegation/*.md` | six packets, ready to send |
| M1, M2, M6, M9, M10, M11 | not written — delegated |

Set `OWNER/DEMO-REPO` in `workflows/gh-issue.v1.json` to the real dummy repo before the first live run. It is the only placeholder in the file.

## Send order

Hour zero, four at once — **Wave A**:
- `docs/delegation/M9_guard_GLM.md`
- `docs/delegation/M6_narrator_GLM.md`
- `docs/delegation/M10_store_Codex.md`
- `docs/delegation/M11_server_Antigravity.md`

Same time, nothing blocks them either — **Wave B**:
- `docs/delegation/M1_driver_Codex.md` ← longest pole, send first if you send anything first
- `docs/delegation/M7_interrupt_Hermes.md` (Demo 2 module, but free to run in parallel)

**Wave C** after M1 lands: M2 resolver (Hermes). For Demo 1 a stub `heal()` returning `None` is acceptable — the self-heal moment is a Demo 3 nice-to-have, not a Demo 1 gate.

Each packet is sent as: full `docs/contracts.md` v2, then the packet body. Nothing else. Do not paraphrase the packet.

## Integration order (master chat, never a delegate)

1. **M9 guard** first. It has no dependencies and M1's blocked-path test needs a real `GuardVerdict` shape to lean on. Run `pytest tests/test_guard.py`.
2. **M10 store**. `pytest tests/test_store.py`. Then check `await load_workflow("gh-issue")` returns the hardcoded spec.
3. **M6 narrator**. `pytest tests/test_narrator.py`. Then swap `FakeNarrator` for the real one in a scratch run against `FakeDriver` — narration should differ per step. If it does not, regenerate; canned narration is a scoring failure, not a polish item.
4. **M1 driver**. `pytest tests/test_driver.py`. Then the live smoke below.
5. **M11 server**. `pytest tests/test_server.py`. Wire `build_orchestrator` to the real Orchestrator + real Driver + real Guard + real Narrator.
6. Full suite: `pytest`. Everything green before recording.

Merge rule stands: a module without passing tests does not get merged, no matter how good it looks.

## Live smoke (by hand, not in CI)

```bash
./launch_browser.sh                 # Chrome on :9222, profile ~/wa-profile
# confirm in the window: github.com is logged in, the demo repo is reachable
python -c "
import asyncio
from playwright.async_api import async_playwright
async def m():
    async with async_playwright() as p:
        b = await p.chromium.connect_over_cdp('http://localhost:9222')
        pg = b.contexts[0].pages[0]
        print(pg.url, await pg.title())
asyncio.run(m())
"
```
That two-liner is the canary. If it prints a URL and a title, the attach path is alive and any later failure is ours, not Chrome's.

Then the real thing:
```bash
uvicorn app.server:app --reload
# open localhost:8000, pick gh-issue, watch it run
```

## Recording checklist

- Chrome window positioned beside the app window, both fully visible, before you hit record.
- Close every other tab. A stray notification in frame means a re-record.
- Record the **whole** run including the page load — the judge needs to believe it is live.
- Say nothing over the top. The narration channel is the point.
- Do one deliberate run past the guard: point the spec at a `Close issue` step and let it refuse on camera. That clip is worth more than a clean run.
- Save as `recordings/demo1-<date>.mp4` the moment it lands. Never rely on live-only.

## Definition of done for Demo 1

- `pytest` fully green.
- One unedited screen recording: real Chrome, real GitHub, ten steps narrated from the live page, issue actually created, nothing hardcoded but the workflow file.
- One recording of a guard refusal.
- Then rotate the chat to Demo 2: replace `_drain_events()`, add M7 + M8 to `Orchestrator.__init__`, write integration cases 2 and 3.

## Known deliberate gaps (do not "fix" these in Demo 1)

- `submit_user_message` parks messages and nothing drains them. That is Demo 2.
- A failed step aborts the run. Retry policy is out of scope.
- `resolver.heal()` may be a stub returning `None`.
- Screencast frames may be a placeholder pane; a real Chrome window beside the app is an acceptable Demo 1 browser view.
