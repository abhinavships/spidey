# DELEGATION PACKET — M7 `app/runtime/interrupt.py` — owner: Hermes — Wave B

> **How to send:** paste the full text of `docs/contracts.md` (v2) first, then everything below this line, in one message.

---

## 1. Your task

Implement **ONLY** `app/runtime/interrupt.py`, plus `tests/test_interrupt.py`. Import only from `app.schemas`, `app.llm`, and stdlib. Do not create, modify, or stub any other file. Do not change any signature in `contracts.md` — if a signature seems wrong, say so and stop.

`app/llm.py` may not exist yet. Import `from app.llm import complete` and let your tests monkeypatch that name. Do not write `app/llm.py`.

## 2. Signature

```python
from app.schemas import InterruptDecision, InterruptKind, WorkflowSpec

async def classify(text: str, spec: WorkflowSpec, cursor: int) -> InterruptDecision
```

That is the whole public surface. One function.

## 3. Behaviour

This is a prompt problem, not a keyword problem — that is why it is yours. A regex over "skip" and "stop" will misfire on "don't skip that" and "stop, I mean go back", and the judge will be talking naturally.

- Classify into exactly one `InterruptKind`. The default when the model is unsure is `UNCLEAR`, never `QUESTION` — a wrong answer is worse than asking.
- Give the model the **step list** (`index`, `id`, `intent` for each step) and the **current cursor** so `JUMP` can map "the part where you save it" to a real index. Do not send `knowledge` blobs; they are large and this call is on the latency path.
- `JUMP` and `SKIP` set `target_step_index`. For `JUMP` it is the destination. For `SKIP` it is the index being skipped (normally `cursor`), or `None` to mean "just this one".
- **A `JUMP` whose index is out of range, or that maps to nothing, must come back as `UNCLEAR`, not as a clamped index.** The orchestrator asks for clarification; it does not guess. Validate the index against `len(spec.steps)` yourself before returning — do not trust the model.
- `rationale` is always non-empty, one short clause, in the agent's own voice. It is logged and sometimes narrated.
- Empty or whitespace-only input → `UNCLEAR` with no model call at all.
- Malformed model output, non-JSON, a `kind` that is not in the enum, or a timeout → `UNCLEAR`. **Never raise.** The classifier runs inside the run loop; an exception here stops a live demo.
- Use JSON mode via `complete(..., json_schema=...)` and strip fences before parsing.
- **4 second timeout.** This call sits between the judge speaking and the agent responding.

Ambiguity guidance to encode in the prompt: questions about *what the agent just did or is looking at* are `QUESTION` even when phrased as a complaint ("wait, why did you click there"). Requests to change *what happens next* are `SKIP`/`JUMP`/`REPEAT`. "Go back" is `JUMP` to an earlier index, not `REPEAT`, unless it names the current step.

## 4. Your tests (from plan_unittests.md §M7 — the spec)

Table-driven, one case per row, all against `FakeLLM` from `tests/fakes.py`:

| input | expected kind |
|---|---|
| "what does that button do?" | QUESTION |
| "wait, why did you click there" | QUESTION |
| "skip this part" | SKIP |
| "just show me the submitting bit" | JUMP |
| "can you do that again" | REPEAT |
| "ok stop" | STOP |
| "hmm" | UNCLEAR |
| "" | UNCLEAR |

Plus:
- Empty input makes **zero** model calls (assert `FakeLLM.prompts == []`)
- JUMP with an in-range target returns that `target_step_index`
- JUMP where the model returns index 99 on a 5-step spec → `UNCLEAR`, not a clamp
- JUMP where the model returns a negative index → `UNCLEAR`
- A `kind` outside the enum → `UNCLEAR`
- Non-JSON model output → `UNCLEAR`, no exception
- Model timeout → `UNCLEAR` within the timeout, no exception
- `rationale` non-empty in every single case above
- The step list is actually in the prompt (assert on `FakeLLM.prompts`)

## 5. Acceptance

Paste back `app/runtime/interrupt.py` and `tests/test_interrupt.py` as two complete files. We run `pytest tests/test_interrupt.py`. Green or regenerate.
