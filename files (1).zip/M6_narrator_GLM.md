# DELEGATION PACKET — M6 `app/runtime/narrator.py` — owner: GLM — Wave A

> **How to send:** paste the full text of `docs/contracts.md` (v2) first, then everything below this line, in one message.

---

## 1. Your task

Implement **ONLY** `app/runtime/narrator.py`, plus `tests/test_narrator.py`. Import only from `app.schemas`, `app.llm`, and stdlib. Do not create, modify, or stub any other file. Do not change any signature in `contracts.md` — if a signature seems wrong, say so and stop.

`app/llm.py` may not exist yet when you start. Import it as `from app.llm import complete` and let your tests monkeypatch that name. Do not write `app/llm.py` yourself.

## 2. Signatures

```python
from app.schemas import PageSnapshot, Step

class Narrator:
    def __init__(self, llm=None) -> None: ...          # llm defaults to app.llm.complete
    async def narrate(self, step: Step, snap: PageSnapshot) -> str: ...
    async def resume_line(self, step: Step, cursor: int, total: int) -> str: ...
```

`narrate` **returns** the text. It does **not** emit — the orchestrator owns the event bus. (contracts.md v1 said "emits, returns text"; v2 corrects this: return only.)

## 3. Behaviour

This module is where the demo either sounds alive or sounds like a script being read. The whole scoring criterion is "narrating from what it sees."

- Build the prompt from **both** `step.narration_hint` and the live `snap` (url, title, and the parts of `visible_text` / `a11y_digest` nearest the step's intent). If two identical steps run against different snapshots, the two outputs must differ. This is tested.
- Output is one or two short spoken sentences, **≤ 300 characters**, present tense, first person, no markdown, no bullet points, no emoji. It is going to a text-to-speech channel in Demo 4.
- Truncate at a sentence boundary if the model overruns; never hard-cut mid-word.
- **6 second timeout** on the model call (`asyncio.wait_for`). On timeout, any exception, or empty output, fall back to `step.narration_hint`, and if that is empty, to `step.intent`. `narrate` must never raise and never return an empty string.
- `resume_line(step, cursor, total)` returns something like `"back to it — step 3 of 5, adding the label"`. Uses 1-based numbering for humans: `cursor + 1` of `total`. This one may be templated locally without a model call; latency matters more than variety here.

## 4. Your tests (from plan_unittests.md §M6 — the spec)

Use `FakeLLM`, `make_spec`, `make_snapshot` from `tests/fakes.py`.

- `narrate()` output is non-empty, ≤ 300 chars, and shares at least one distinctive token with the live snapshot's text
- **Same step, two different snapshots → two different outputs.** This is the anti-canned-script test and it is a scoring criterion. Do not weaken it.
- `resume_line()` contains the correct step number and total (`"3 of 5"` for cursor=2, total=5)
- LLM raises → falls back to `narration_hint`, no exception escapes
- LLM hangs past 6s → falls back within ~6s (patch the timeout constant down in the test; do not make the suite sleep 6 real seconds)
- LLM returns `""` → falls back rather than emitting empty
- Model output of 900 chars → returned text is ≤ 300 and does not end mid-word

## 5. Acceptance

Paste back `app/runtime/narrator.py` and `tests/test_narrator.py` as two complete files. We run `pytest tests/test_narrator.py`. Green or regenerate.
