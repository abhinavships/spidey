# plan.md — Live Walkthrough Agent — **v2**

## What we are building, in one paragraph

A web app with two modes. In **teach mode** (done days before the demo) you describe a short workflow in plain language; the agent drives a real browser on a dummy account, walks the workflow live, resolves each step against the actual page, asks you when it's unsure, and freezes what worked into a saved workflow file. In **call mode** a judge opens a chat page with a live browser view beside it, asks for that workflow, and the agent drives the real browser step by step, narrating from what it sees. When the judge interrupts, the agent answers from what it actually captured during teaching plus the live page, then resumes at exactly the step it was on. Two modes, one artifact between them, one cursor that questions never move.

**Target site (v2): GitHub.** Primary workflow: *create an issue with a label and an assignee* (open repo → New issue → title → body → Labels → pick one → Assignees → pick one → Submit). Reversible, no real-world side effect, DOM is `data-testid`-rich and stable. The **Close issue / Delete repository** controls are on screen specifically so the guard can be shown refusing them.
**Stretch:** Gmail — create an email signature. Already logged into the profile.
**Backup:** Trello — create a card. Simplest DOM of the three. Taught and frozen as insurance before demo day.

## Locked decisions

| Decision | Choice | Why |
|---|---|---|
| Browser | **Playwright 1.62.0, CDP attach to real Chrome on :9222** | Google blocks Playwright-launched Chromium at login. Attaching to a manually-logged-in Chrome sidesteps it entirely. Verified working. |
| Profile | Persistent at `~/wa-profile`, GitHub + Gmail logged in | Survives restarts; no login step in the demo |
| a11y capture | `await page.locator("body").aria_snapshot()` | `page.accessibility` is REMOVED in 1.62 |
| Firecrawl | Not used | Stateless read tool. No session, no cursor, no live drive |
| Execution | Saved locator first, LLM self-heal on miss | Deterministic happy path; survives UI drift; the heal is a good live moment |
| Teaching | NL description → compile → **live rehearsal** → freeze | Handles ambiguity natively (bonus), proves the path once before demo day, far less code than a click recorder |
| Interruptions | Event queue drained in a loop, cursor untouched by questions | One design yields single, consecutive, and plan-changing interruptions |
| QA grounding | Captured StepKnowledge + live snapshot only, may decline | "Using what it actually knows" is judged. A confident *I don't know* beats a hallucination |
| Stack | Python 3.11, Playwright, FastAPI + WebSocket, vanilla JS UI | No build step, nothing to debug at 3am |

## The four demos

We do not build modules and integrate at the end. We build four **runnable, screen-recordable** demos, each strictly containing the last. Miss Demo 4 entirely and we still ship a complete must-have.

### Demo 1 — Walking skeleton *(proves it's real)* — **IN FLIGHT**
Hardcoded `workflows/gh-issue.v1.json`. Real Playwright, attached over CDP, drives real Chrome on GitHub. Chat UI streams narration, live browser visible beside it. Safety guard in from the first commit.
- Modules: M0 ✅, M1, M2 (stub heal), M5 v0 ✅ (linear loop, no event queue), M6, M9, M10, M11
- **Done when:** a clean run recorded end to end with nothing hardcoded except the workflow file, and `tests/test_integration.py::test_clean_run_all_steps_done_in_order` green.
- Risk retired: "does it actually drive a browser live" — the thing everything else assumes.

### Demo 2 — Interruption *(the must-have, minus teaching)*
Event queue + cursor + classifier + grounded QA. M5 v0's `_drain_events()` stub is replaced; nothing else in the loop changes. Workflow still hardcoded — but knowledge blocks hand-filled so QA has something real to be grounded in.
- Modules: M5 (full loop), M7, M8
- **Done when:** three consecutive unscripted questions mid-run, all answered, run completes correctly, and one deliberately out-of-scope question gets a clean "that wasn't part of what I was shown."
- Risk retired: the single hardest-to-fake scoring criterion.

### Demo 3 — Teaching *(closes the must-have, unlocks reuse)*
NL → compiler → rehearser → frozen spec. The Demo 1 hardcoded JSON is **deleted** and replaced by a taught one. Reuse (bonus) comes free: the artifact is already on disk and `list_workflows` already exists.
- Modules: M3, M4
- **Done when:** a workflow taught only from one paragraph of plain English, including one deliberately vague sentence, runs cleanly in call mode. Backup Trello workflow taught the same day.

### Demo 4 — Bonuses
Plan-changing interruptions (SKIP / JUMP / REPEAT wired to the cursor — the classifier already returns them, this is just handling), then voice narration (M12, TTS on the narration channel).
- **Done when:** judge says "skip ahead to the part where you submit it" and the agent does, narrating the jump.

Post-demo backlog, explicitly out of this build: human-in-the-loop approval gates, auth hardening, multi-site workflow libraries, richer security model.

## Module ownership

Hermes gets everything prompt-shaped — that's its strength and the organizers want it used. Codex/GLM get plumbing. The orchestrator stays in-house because it's where integration bugs live.

| # | Module | Owner | Demo | Status |
|---|---|---|---|---|
| M0 | `schemas.py` | **Claude master, alone, first** | 1 | ✅ written, frozen |
| M1 | `browser/driver.py` | Codex | 1 | Wave B — packet written |
| M2 | `browser/resolver.py` | **Hermes** | 1 (stub) / 3 (full) | Wave C |
| M3 | `teach/compiler.py` | **Hermes** | 3 | — |
| M4 | `teach/rehearser.py` | **Hermes** | 3 | — |
| M5 | `runtime/orchestrator.py` | **Claude master** | 1, 2 | ✅ v0 written |
| M6 | `runtime/narrator.py` | GLM | 1 | Wave A — packet written |
| M7 | `runtime/interrupt.py` | **Hermes** | 2 | Wave B — packet written |
| M8 | `runtime/qa.py` | **Hermes** | 2 | — |
| M9 | `safety/guard.py` | GLM | 1 | Wave A — packet written |
| M10 | `store.py` | Codex | 1 | Wave A — packet written |
| M11 | `server.py` + UI | Antigravity | 1 | Wave A — packet written |
| M12 | voice | anyone | 4 | — |

**M0 was written by us and frozen before a single delegation prompt went out.** `tests/fakes.py` and `tests/test_integration.py` are also in-house and are **not** editable by delegates.

## Delegation protocol

Every delegated task is one message containing exactly four things:

1. Full text of `docs/contracts.md` (v2)
2. The module's section from `docs/plan_unittests.md` (the tests are the spec)
3. `"Implement ONLY app/<path>.py. Import only from app.schemas and your declared dependencies. Do not create, modify, or stub any other file — including tests/fakes.py. Do not change any signature in contracts.md — if a signature seems wrong, say so and stop."`
4. Site-specific notes if any (GitHub DOM quirks, CDP attach recipe, etc.)

Acceptance: paste back the file, we run its tests. Green or regenerate. **We do not read delegated code closely — we read test output.** That is what makes the no-agentic-coding approach viable.

Anti-drift rules, learned the hard way:
- Never let two delegates touch one file.
- Never let a delegate invent a schema. If it needs a new type, it comes back to us and goes into `contracts.md` v3.
- Integration is always done by the master chat, never by a delegate.
- A module without passing tests does not get merged, no matter how good it looks.

## Parallelization

**Wave A (nothing blocks these):** M9 guard, M10 store, M11 server+UI shell, M6 narrator. Four delegates at once, hour zero.
**Wave B (needs M0 only, which exists):** M1 driver, M7 classifier.
**Wave C (needs M1):** M2 resolver, then M4 rehearser.
**In-house throughout:** M5 orchestrator, integration, demo recording.

## Demo-day risk register

| Risk | Mitigation |
|---|---|
| GitHub DOM shifts between teach and demo | Self-heal path; re-run rehearsal the morning of |
| Chrome not running on :9222 when the demo starts | `./launch_browser.sh` in the runbook; server returns a clear "no browser attached" error, not a stack trace |
| Someone closes the attached tab mid-run | `stop()` detaches rather than closes; driver re-reads `contexts[0].pages[0]` on each act |
| Account flagged / 2FA challenge | Profile at `~/wa-profile` warmed by normal use days early; Trello backup |
| Live model latency stalls narration | Narration streams; 6s timeout falls back to `narration_hint`; classifier + QA share one call where possible |
| Judge asks something genuinely unknowable | QA declines cleanly. This is a designed outcome, not a failure |
| Network dies during the demo | Screen recording of a full clean run kept ready to play |
| Wi-Fi/venue latency on screencast | Frame rate throttled to 5fps, quality tunable |

## Definition of done for the submission

- Must-have: taught workflow, live driven browser, live narration, ≥1 interruption answered and resumed, dummy account only, no destructive actions. **All four demos above satisfy this by Demo 3.**
- Bonuses claimed in order of certainty: consecutive interruptions (free, Demo 2), reuse (free, Demo 3), messy teaching input (Demo 3), plan-changing interruptions (Demo 4), voice (Demo 4).
- Recording of each demo kept as it lands. Never rely on live-only.
