# DELEGATION PACKET — M10 `app/store.py` — owner: Codex — Wave A

> **How to send:** paste the full text of `docs/contracts.md` (v2) first, then everything below this line, in one message.

---

## 1. Your task

Implement **ONLY** `app/store.py`, plus `tests/test_store.py`. Import only from `app.schemas` and stdlib (plus `anyio`/`aiofiles` if you want async file I/O — `asyncio.to_thread` around plain `pathlib` is fine and preferred, fewer deps). Do not create, modify, or stub any other file. Do not change any signature in `contracts.md` — if a signature seems wrong, say so and stop.

## 2. Signatures

```python
from app.schemas import WorkflowNotFound, WorkflowSpec, WorkflowSummary

WORKFLOWS_DIR: Path = Path("workflows")   # module-level, overridable in tests

async def save_workflow(spec: WorkflowSpec) -> str: ...            # returns the path written
async def load_workflow(workflow_id: str, version: int | None = None) -> WorkflowSpec: ...
async def list_workflows() -> list[WorkflowSummary]: ...
```

## 3. Behaviour

- Filename is exactly `{id}.v{version}.json`. Serialise with `spec.model_dump_json(indent=2)`.
- `save_workflow` writes **atomically**: write to `{name}.tmp` in the same directory, then `os.replace`. A half-written spec discovered on demo morning is a bad morning.
- `save_workflow` creates `WORKFLOWS_DIR` if it does not exist.
- `load_workflow(id)` with `version=None` returns the **highest** version present. `load_workflow(id, 2)` returns exactly v2 or raises.
- Missing id, missing version, or a file that fails `model_validate` → raise `WorkflowNotFound` with a message naming the id and what was looked for. Do not raise `FileNotFoundError` or `ValidationError` to the caller.
- `list_workflows()` returns one `WorkflowSummary` **per id at its highest version**, sorted by `id`. Empty or missing directory → `[]`, not an exception.
- Ignore any file in the directory that does not match the filename pattern. A stray `.DS_Store` or `notes.md` must not crash the listing that the UI calls on page load.
- Make `WORKFLOWS_DIR` a module-level name your tests can monkeypatch to a `tmp_path`. **No test may write into the real `workflows/` directory** — the frozen demo spec lives there.

## 4. Your tests (from plan_unittests.md §M10 — the spec)

- Save then load → identical spec (`==` on the model, not on the JSON string)
- Save v1 then v2 → both retrievable by explicit version; `load(id)` with no version returns v2
- `load()` of a missing id raises `WorkflowNotFound`
- `load(id, 7)` when only v1 exists raises `WorkflowNotFound`
- A corrupt JSON file for a valid id raises `WorkflowNotFound`, not `ValidationError`
- `list_workflows()` on an empty dir returns `[]`; on a missing dir returns `[]`
- `list_workflows()` with v1 and v2 of one id returns **one** row, showing v2
- A junk file in the directory is ignored by `list_workflows()`
- Filenames match `{id}.v{n}.json` (assert on the actual directory contents)
- No `.tmp` file is left behind after a successful save

## 5. Acceptance

Paste back `app/store.py` and `tests/test_store.py` as two complete files. We run `pytest tests/test_store.py`. Green or regenerate.
