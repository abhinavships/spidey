# DELEGATION PACKET — M11 `app/server.py` + `ui/` — owner: Antigravity — Wave A

> **How to send:** paste the full text of `docs/contracts.md` (v2) first, then everything below this line, in one message.

---

## 1. Your task

Implement **ONLY** `app/server.py`, `ui/index.html`, `ui/app.js`, `ui/style.css`, plus `tests/test_server.py`. Import only from `app.schemas`, `app.store`, `app.runtime.orchestrator`, FastAPI/uvicorn/starlette, and stdlib. Do not create, modify, or stub any other file. Do not change any signature in `contracts.md` — if a signature seems wrong, say so and stop.

**You do not write the orchestrator, the driver, or the guard.** They are other people's modules. Your job is the socket, the routes, and the page. Where you need an orchestrator, construct it through a single module-level factory function so we can swap in fakes:

```python
def build_orchestrator(spec, session_id, emit) -> Orchestrator: ...   # tests monkeypatch this
```

## 2. Routes

- `GET /` → 200, serves `ui/index.html`. Static files under `/static`.
- `GET /api/workflows` → JSON list from `await list_workflows()`.
- `WS /ws/{session_id}` → speaks contracts.md §6.

Inbound frames are exactly two shapes; anything else is an error:
```json
{"kind": "start_run", "workflow_id": "gh-issue"}
{"kind": "user_message", "text": "wait, what does that toggle do?"}
```

Outbound frames are `Event.model_dump(mode="json")` and nothing else. Never invent a field; never send a bare string.

## 3. Behaviour that will bite you

- **`user_message` must reach the orchestrator via `submit_user_message(text)`, which is synchronous and non-blocking.** Never `await` it. Never queue it yourself. In Demo 1 the orchestrator parks the message and does nothing with it — that is expected and not a bug on your side.
- The run happens in a background task (`asyncio.create_task`) so the socket stays readable while steps execute. If you `await orchestrator.run()` inline, interruptions die and Demo 2 is impossible.
- Malformed JSON, unknown `kind`, or a missing field → send one `Event(type="error", ...)` with a readable `text` and **keep the socket open**.
- Client disconnect mid-run → cancel the run task and call `driver.stop()`, which **detaches** from Chrome rather than closing it. Never leave an orphan task.
- **No Chrome on :9222** → the CDP attach raises. Catch it and send `Event(type="error", text="No browser attached — run ./launch_browser.sh and try again.")`. A traceback on the judge's screen is worse than a failed run.
- `frame` events (base64 CDP screencast, 5fps) share the same socket. In Demo 1 you may stub the frame source behind a flag; the browser view can be a real Chrome window beside the app for the first recording.

## 4. The UI

Two panes, vertical split. Left: chat transcript. Right: the live browser view (frames, or a placeholder card in Demo 1). Vanilla JS, no build step, no framework, no CDN at runtime — venue Wi-Fi is a listed risk.

Render by event type, and make these four **visually distinct**, because they are the moments a judge scores:
- `narration` — the agent's voice, primary styling
- `heal` — "the page moved, I re-found it" — show it, do not hide it
- `blocked` — the refusal. Give it the loudest treatment on the page. This is a feature.
- `step_start` / `step_done` — a step list down the side with a live cursor marker

A reconnect on socket close, and a visible connection indicator. Nothing else. Do not add settings panels, themes, or animations we will have to debug at 3am.

## 5. Your tests (from plan_unittests.md §M11 — the spec)

Use `fastapi.testclient.TestClient` and monkeypatch `build_orchestrator`.

- `GET /` returns 200 and HTML
- `GET /api/workflows` returns the list from the store (patch `list_workflows`)
- WS accepts `start_run` and emits `run_started` within 2s
- WS `user_message` mid-run reaches the orchestrator — assert via a spy that `submit_user_message` was called with the exact text
- Malformed WS JSON → one `error` event, socket still accepts a following valid frame
- Unknown `kind` → `error` event, socket stays open
- Client disconnect mid-run → the run task is cancelled and `driver.stop()` was called (spy)
- Attach failure → `error` event whose text mentions the browser, and no exception propagates

## 6. Acceptance

Paste back all five files complete. We run `pytest tests/test_server.py`. Green or regenerate.
