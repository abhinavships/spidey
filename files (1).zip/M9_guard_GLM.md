# DELEGATION PACKET — M9 `app/safety/guard.py` — owner: GLM — Wave A

> **How to send:** paste the full text of `docs/contracts.md` (v2) first, then everything below this line, in one message.

---

## 1. Your task

Implement **ONLY** `app/safety/guard.py`. Import only from `app.schemas` and the standard library. Do not create, modify, or stub any other file — including `tests/fakes.py` and `app/schemas.py`. Do not change any signature in `contracts.md` — if a signature seems wrong, say so and stop.

Also write `tests/test_guard.py` covering exactly the cases in §3 below, using `tests/fakes.py` (`make_spec`, `make_snapshot`). That is the only other file you may create.

## 2. Signatures (from contracts.md §7 M9 — reproduced so you cannot drift)

```python
from app.schemas import GuardVerdict, PageSnapshot, RiskLevel, Step

class Guard:
    def __init__(self, allowed_domains: list[str]) -> None: ...
    def check(self, step: Step, snap: PageSnapshot) -> GuardVerdict: ...
```

`check` is **synchronous** and **pure** — no I/O, no model call, no logging side effects beyond `structlog`. It must never raise; an unparseable input is a `GuardVerdict(allowed=False, ...)` with a reason, not an exception. `BlockedAction` lives in `app.schemas` and is raised by M1, **not by you**.

What `check` inspects, in this order:
1. **Domain.** For `ActionType.NAVIGATE`, the host of `step.value`; for everything else, the host of `snap.url`. If the host is not in `allowed_domains` or a subdomain of one of them, refuse. Use `urllib.parse.urlsplit`, not string matching. `github.com` must allow `www.github.com` and not allow `notgithub.com` or `github.com.evil.io`.
2. **Destructive vocabulary.** Match against `step.intent`, `step.locator.intent` if present, and `locator.candidates[*].name` / `.value`. **Word-boundary, case-insensitive** — build a compiled regex per phrase with `\b`. Multi-word phrases match across a single run of whitespace.
3. **Declared risk.** `step.risk is RiskLevel.DESTRUCTIVE` always refuses, whatever the text says.

Destructive vocabulary (v2, final): `send`, `delete`, `delete permanently`, `delete forever`, `empty trash`, `buy`, `purchase`, `publish`, `deactivate`, `unsubscribe all`, `confirm payment`, `merge pull request`, `close issue`, `transfer ownership`, `delete repository`.

Caution vocabulary (allowed, but `RiskLevel.CAUTION`): `save`, `submit`, `create`, `add`, `update`, `apply`, `rename`.

Everything else is `RiskLevel.SAFE` and allowed.

`reason` is spoken aloud to a judge. Write it in the first person and make it specific: `"I won't click 'Delete repository' — that can't be undone."` not `"blocked: policy violation"`. Never leave it empty, including on the allow path.

## 3. Your tests (from plan_unittests.md §M9 — the spec)

- Off-allowlist navigation → `allowed=False`
- "Send" on a compose screen → `DESTRUCTIVE`, blocked
- "Delete forever" / "Empty trash" / "Buy now" / "Publish" → blocked
- GitHub: "Merge pull request" / "Close issue" / "Delete repository" / "Transfer ownership" → blocked
- "Save changes" → `CAUTION`, allowed
- **"Submit new issue" → `CAUTION`, allowed** — the primary workflow ends on this button. A guard that blocks it kills the demo. Test it explicitly.
- "Open settings" → `SAFE`, allowed
- Word-boundary: "Resend", "Sender", "Closed issues", "Undelete" must NOT trip their rules
- `step.risk = DESTRUCTIVE` refuses even when the text is innocuous
- Subdomain handling: `www.github.com` allowed under `["github.com"]`; `github.com.evil.io` refused
- Every verdict — allowed or refused — has a non-empty `reason`

## 4. Site notes

The demo runs on GitHub. On the new-issue page the destructive controls (`Close issue`, `Delete`) sit near `Submit new issue`, so substring matching will produce a false block and lose us the run. Word boundaries are not optional here.

## 5. Acceptance

Paste back `app/safety/guard.py` and `tests/test_guard.py` as two complete files. We run `pytest tests/test_guard.py`. Green or regenerate. We will not read the implementation closely — we read test output.
