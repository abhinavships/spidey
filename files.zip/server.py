"""app/server.py — M11. FastAPI + one WebSocket that speaks contracts.md §6.

Usage:
    uvicorn app.server:app --reload      # then open http://localhost:8000
"""

from __future__ import annotations

import asyncio
import json
import os
from datetime import datetime, timezone
from pathlib import Path

import structlog
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app.browser.driver import Driver
from app.browser.resolver import Resolver
from app.runtime.narrator import Narrator
from app.runtime.orchestrator import Orchestrator
from app.safety.guard import Guard
from app.schemas import Event, WorkflowNotFound, WorkflowSpec
from app.store import list_workflows, load_workflow

log = structlog.get_logger(__name__)

UI_DIR = Path(__file__).resolve().parent.parent / "ui"
CDP_ENDPOINT = os.getenv("WA_CDP", "http://localhost:9222")

app = FastAPI(title="Live Walkthrough Agent")
if UI_DIR.exists():
    app.mount("/static", StaticFiles(directory=UI_DIR), name="static")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def build_orchestrator(spec: WorkflowSpec, session_id: str, emit, driver: Driver):
    """Assemble the real runtime. Monkeypatched in tests.

    Usage:
        orch = build_orchestrator(spec, "s1", emit, driver)
    """
    return Orchestrator(
        spec=spec, driver=driver, resolver=Resolver(), narrator=Narrator(),
        guard=Guard([spec.target_domain]), emit=emit, session_id=session_id,
    )


@app.get("/")
async def index():
    """Serve the single-page UI."""
    return FileResponse(UI_DIR / "index.html")


@app.get("/api/workflows")
async def api_workflows():
    """List saved workflows for the picker."""
    return JSONResponse([w.model_dump(mode="json") for w in await list_workflows()])


@app.websocket("/ws/{session_id}")
async def ws(sock: WebSocket, session_id: str) -> None:
    """One session: start_run and user_message in, Events out."""
    await sock.accept()
    lock = asyncio.Lock()

    async def emit(event: Event) -> None:
        async with lock:
            try:
                await sock.send_text(event.model_dump_json())
            except Exception as exc:  # noqa: BLE001 - client may have vanished
                log.warning("emit_failed", error=str(exc))

    async def error(text: str) -> None:
        await emit(Event(type="error", session_id=session_id, ts=_now(), text=text))

    driver: Driver | None = None
    orch: Orchestrator | None = None
    task: asyncio.Task | None = None

    async def run(workflow_id: str) -> None:
        nonlocal driver, orch
        try:
            spec = await load_workflow(workflow_id)
        except WorkflowNotFound as exc:
            await error(str(exc))
            return
        driver = Driver()
        try:
            await driver.start(spec.entry_url, cdp_endpoint=CDP_ENDPOINT)
        except RuntimeError as exc:
            await error(str(exc))
            driver = None
            return
        orch = build_orchestrator(spec, session_id, emit, driver)
        try:
            await orch.run()
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 - boundary: report, don't crash the socket
            log.exception("run_crashed")
            await error(f"the run stopped unexpectedly: {exc}")
        finally:
            if driver:
                await driver.stop()
                driver = None

    try:
        while True:
            raw = await sock.receive_text()
            try:
                msg = json.loads(raw)
                kind = msg["kind"]
            except (json.JSONDecodeError, KeyError, TypeError):
                await error("I couldn't read that message.")
                continue

            if kind == "start_run":
                if task and not task.done():
                    await error("a run is already in progress")
                    continue
                task = asyncio.create_task(run(msg.get("workflow_id", "")))
            elif kind == "user_message":
                if orch is None:
                    await error("nothing is running yet")
                else:
                    orch.submit_user_message(msg.get("text", ""))
            else:
                await error(f"unknown message kind {kind!r}")
    except WebSocketDisconnect:
        log.info("client_disconnected", session_id=session_id)
    finally:
        if task and not task.done():
            task.cancel()
        if driver:
            await driver.stop()
