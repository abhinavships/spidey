"""app/runtime/orchestrator.py — M5 v0 (Demo 1).

Linear run loop. NO event queue: `submit_user_message` accepts and parks
messages so the WebSocket layer can be written against the final signature,
but nothing drains them yet. Demo 2 replaces `_drain_events` with the real
implementation and adds Interrupter/QA to `__init__`. Everything else in this
file is meant to survive that change unedited.

The cursor invariant is enforced here structurally: `cursor` is mutated in
exactly one place, `_advance()`.

Usage:
    orch = Orchestrator(spec, driver, resolver, narrator, guard, emit, session_id="s1")
    state = await orch.run()
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any

import structlog

from app.schemas import (
    ActResult,
    BlockedAction,
    Event,
    EventType,
    PageSnapshot,
    RunState,
    SessionState,
    Step,
    StepRecord,
    StepStatus,
    WorkflowSpec,
)

log = structlog.get_logger(__name__)

STEP_HARD_TIMEOUT_S = 30.0
NARRATION_TIMEOUT_S = 6.0


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Orchestrator:
    """Runs one WorkflowSpec against one browser session.

    Usage:
        Orchestrator(spec, driver, resolver, narrator, guard, emit).run()
    """

    def __init__(
        self,
        spec: WorkflowSpec,
        driver: Any,
        resolver: Any,
        narrator: Any,
        guard: Any,
        emit: Any,
        session_id: str = "session",
    ) -> None:
        self.spec = spec
        self.driver = driver
        self.resolver = resolver
        self.narrator = narrator
        self.guard = guard
        self.emit = emit
        self._queue: asyncio.Queue[str] = asyncio.Queue()
        self._state = SessionState(
            session_id=session_id,
            workflow_id=spec.id,
            cursor=0,
            state=RunState.IDLE,
            records=[],
        )

    # -- public -----------------------------------------------------------

    @property
    def state(self) -> SessionState:
        """The live session state. Read-only by convention.

        Usage:
            orch.state.cursor
        """
        return self._state

    def submit_user_message(self, text: str) -> None:
        """Enqueue a user message. Never blocks, never awaits.

        v0 parks the message and logs it; Demo 2 drains it in `_drain_events`.

        Usage:
            orch.submit_user_message("wait, what does that do?")
        """
        self._queue.put_nowait(text)
        log.info("user_message_parked", text=text, cursor=self._state.cursor)

    async def run(self) -> SessionState:
        """Execute the workflow start to finish and return the final state.

        Usage:
            state = await orch.run()
        """
        s = self._state
        s.state = RunState.RUNNING
        await self._emit("run_started", text=self.spec.title, cursor=s.cursor)

        while s.cursor < len(self.spec.steps) and s.state is RunState.RUNNING:
            await self._drain_events()
            if s.cursor >= len(self.spec.steps) or s.state is not RunState.RUNNING:
                break

            step = self.spec.steps[s.cursor]
            await self._run_step(step)
            await self._drain_events()

        if s.state is RunState.RUNNING:
            s.state = RunState.COMPLETED
            await self._emit("run_completed", cursor=s.cursor)
        elif s.state is RunState.ABORTED:
            await self._emit("run_aborted", cursor=s.cursor)
        return s

    # -- internals --------------------------------------------------------

    async def _run_step(self, step: Step) -> None:
        record = StepRecord(step_id=step.id, status=StepStatus.RUNNING, started_at=_now())
        self._state.records.append(record)
        await self._emit("step_start", text=step.intent, step_id=step.id,
                         cursor=self._state.cursor)

        snap = await self._safe_snapshot()
        await self._narrate(step, snap)

        try:
            result = await asyncio.wait_for(
                self.driver.act(step, self.resolver, self.guard),
                timeout=STEP_HARD_TIMEOUT_S,
            )
        except BlockedAction as exc:
            record.status = StepStatus.BLOCKED
            record.ended_at = _now()
            record.error = exc.verdict.reason
            await self._emit("blocked", text=exc.verdict.reason, step_id=step.id,
                             cursor=self._state.cursor,
                             data={"risk": exc.verdict.risk.value})
            self._advance()
            return
        except asyncio.TimeoutError:
            result = ActResult(ok=False, error=f"step timed out after {STEP_HARD_TIMEOUT_S}s")
        except Exception as exc:  # noqa: BLE001 - boundary: one step must not kill a demo
            log.exception("step_crashed", step_id=step.id)
            result = ActResult(ok=False, error=f"{type(exc).__name__}: {exc}")

        record.healed = result.healed
        record.ended_at = _now()
        if result.healed:
            await self._emit("heal", text=f"the page moved, I re-found it: {step.intent}",
                             step_id=step.id, cursor=self._state.cursor)

        if result.ok:
            record.status = StepStatus.DONE
            await self._emit("step_done", text=result.effect, step_id=step.id,
                             cursor=self._state.cursor)
            self._advance()
        else:
            record.status = StepStatus.FAILED
            record.error = result.error
            await self._emit("step_failed", text=result.error, step_id=step.id,
                             cursor=self._state.cursor)
            self._handle_failure(step, result)

    def _handle_failure(self, step: Step, result: ActResult) -> None:
        """Demo 1 policy: a failed step aborts the run and never moves the cursor."""
        self._state.state = RunState.ABORTED

    def _advance(self) -> None:
        """The ONLY place the cursor moves during normal execution."""
        self._state.cursor += 1

    async def _drain_events(self) -> None:
        """v0 no-op. Demo 2 classifies and handles each parked message here.

        Questions must leave `cursor` untouched; only SKIP/JUMP may move it.
        """
        return None

    async def _narrate(self, step: Step, snap: PageSnapshot) -> None:
        try:
            text = await asyncio.wait_for(
                self.narrator.narrate(step, snap), timeout=NARRATION_TIMEOUT_S
            )
        except Exception as exc:  # noqa: BLE001 - narration must never stall a demo
            log.warning("narration_fallback", step_id=step.id, error=str(exc))
            text = step.narration_hint or step.intent
        if text:
            await self._emit("narration", text=text, step_id=step.id,
                             cursor=self._state.cursor)

    async def _safe_snapshot(self) -> PageSnapshot:
        try:
            return await self.driver.snapshot()
        except Exception as exc:  # noqa: BLE001 - snapshot is advisory, not fatal
            log.warning("snapshot_failed", error=str(exc))
            return PageSnapshot(url="", title="")

    async def _emit(self, type_: EventType, *, text: str | None = None,
                    step_id: str | None = None, cursor: int | None = None,
                    data: dict[str, Any] | None = None) -> None:
        await self.emit(Event(type=type_, session_id=self._state.session_id, ts=_now(),
                              text=text, step_id=step_id, cursor=cursor, data=data or {}))
