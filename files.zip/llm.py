"""app/llm.py — the single model entry point.

If ANTHROPIC_API_KEY is absent the module degrades to `None` returns rather than
raising, so the whole demo still runs without a key. Callers must already have a
fallback (the narrator falls back to narration_hint).

Usage:
    text = await complete("You narrate a walkthrough.", "Describe this step.")
"""

from __future__ import annotations

import json
import os
from typing import Any

import structlog

log = structlog.get_logger(__name__)

MODEL = os.getenv("WA_MODEL", "claude-sonnet-4-6")
TIMEOUT_S = float(os.getenv("WA_LLM_TIMEOUT", "6"))


def available() -> bool:
    """True when a model call can actually be made.

    Usage:
        if available(): ...
    """
    return bool(os.getenv("ANTHROPIC_API_KEY"))


def _strip_fences(text: str) -> str:
    t = text.strip()
    if t.startswith("```"):
        t = t.split("\n", 1)[-1]
        t = t.rsplit("```", 1)[0]
    return t.strip()


async def complete(system: str, user: str, json_schema: dict | None = None,
                   max_tokens: int = 1024) -> Any:
    """Call the model once, with one retry. Returns str, or dict in JSON mode.

    Returns None when no API key is configured.

    Usage:
        out = await complete("You are terse.", "Say hi.")
    """
    if not available():
        log.warning("llm_unavailable_no_key")
        return None

    import anthropic  # imported lazily so the demo runs without the sdk installed

    client = anthropic.AsyncAnthropic(timeout=TIMEOUT_S)
    suffix = "\n\nReply with JSON only. No prose, no code fences." if json_schema else ""

    last: Exception | None = None
    for attempt in (1, 2):
        try:
            msg = await client.messages.create(
                model=MODEL,
                max_tokens=max_tokens,
                system=system + suffix,
                messages=[{"role": "user", "content": user}],
            )
            text = "".join(b.text for b in msg.content if b.type == "text")
            if not json_schema:
                return text
            return json.loads(_strip_fences(text))
        except Exception as exc:  # noqa: BLE001 - boundary: a demo must not die here
            last = exc
            log.warning("llm_call_failed", attempt=attempt, error=str(exc))
    log.error("llm_gave_up", error=str(last))
    return None
